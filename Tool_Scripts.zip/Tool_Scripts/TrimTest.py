# Test for clipping

import arcpy
import os

arcpy.env.overwriteOutput = True

Railroads = arcpy.GetParameterAsText(0)
TrimPolygon = arcpy.GetParameterAsText(1)
folder = arcpy.GetParameterAsText(2)
name = arcpy.GetParameterAsText(3)
arcpy.AddMessage('parameters are in')
#trimmedRailroads = 'trimmedRailroads'
tempRail = 'tempRail'
tempPoly = 'tempPoly'
ToAdd = 'trimmed' + name + 'layer'
#RailroadLayer = 'RailroadLayer'
arcpy.AddMessage('output set')
#if os.path.exists(trimmedRailroads):
#	os.remove(trimmedRailroads)
arcpy.AddMessage('existing file, if any, removed')
InputLayer = arcpy.MakeFeatureLayer_management(Railroads, tempRail)
arcpy.AddMessage('trimmed' + Railroads)
InputClipLayer = arcpy.MakeFeatureLayer_management(TrimPolygon, tempPoly)
tempClip = arcpy.Clip_analysis(InputLayer, InputClipLayer, 'trimmed' + name)
arcpy.AddMessage('clipped')
arcpy.MakeFeatureLayer_management(tempClip, 'trimmed' + name + 'layer')
arcpy.AddMessage('saved as layer')
mxd = arcpy.mapping.MapDocument('CURRENT')
arcpy.AddMessage('mxd')
df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]
arcpy.AddMessage('df')
layer = arcpy.mapping.Layer(ToAdd)
arcpy.mapping.AddLayer(df, layer, 'TOP')
arcpy.AddMessage('layer added')
arcpy.RefreshActiveView()
arcpy.RefreshTOC()
