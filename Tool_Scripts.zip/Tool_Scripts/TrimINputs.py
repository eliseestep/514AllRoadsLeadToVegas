import arcpy

in_vector = arcpy.GetParameterAsText(0)
in_raster = arcpy.GetParameterAsText(1)

def TrimInputs