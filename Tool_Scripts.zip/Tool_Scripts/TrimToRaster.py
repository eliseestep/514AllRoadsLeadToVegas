import arcpy

in_vector = arcpy.GetParameterAsText(0)
in_raster = arcpy.GetParameterAsText(1)

def TrimToRaster(in_vector, in_raster):
	'''This function will trim vector shapefiles to the extent of an input raster'''
	pnt_array = arcpy.Array()
	extent = arcpy.Raster(in_raster).extent
	pnt_array.add(extent.lowerLeft)
	pnt_array.add(extent.lowerRight)
	pnt_array.add(extent.upperRight)
	pnt_array.add(extent.upperLeft)
	poly = arcpy.Polygon(pnt_array)
	#temp_out = 'trimmed' + in_vector
	#arcpy.Clip_analysis(in_vector, poly, temp_out)
	mxd = arcpy.mapping.MapDocument('CURRENT')
	df = arcpy.mapping.ListDataFrames(mxd, 'Layers')[0]
	arcpy.MakeFeatureLayer_management(poly,temp_layer)
	arcpy.mapping.AddLayer(df, temp_layer, 'TOP')