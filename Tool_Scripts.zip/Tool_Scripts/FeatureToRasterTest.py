import arcpy
import os
from arcpy.sa import *

Railroads = arcpy.GetParameterAsText(0)
TrimPolygon = arcpy.GetParameterAsText(1)
Geodatabase = arcpy.GetParameterAsText(2)
cellsize_option = arcpy.GetParameterAsText(3)

arcpy.env.cellSize = cellsize_option

mxd = arcpy.mapping.MapDocument('CURRENT')
df = arcpy.mapping.ListDataFrames(mxd,'Layers')[0]

temp_shape = 'temp_shape'
temp_clip = 'temp_clip'
Railroad_Buffer = 'Railroad_Buffer'
Railroad_Raster = 'Railroad_Raster'

def TrimInputs(in_shape, trim_shape, name, mxd, df):
	'''trimming and adding shapefile inputs to the map'''
	inputshape = arcpy.MakeFeatureLayer_management(in_shape, temp_shape)
	inputclip = arcpy.MakeFeatureLayer_management(trim_shape, temp_clip)
	ClipOut = arcpy.Clip_analysis(inputshape, inputclip, 'trimmed' + name)
	arcpy.MakeFeatureLayer_management(ClipOut, 'trimmed' + name + 'layer')
	#ToAdd = 'trimmed' + name + 'layer'
	#layer = arcpy.mapping.Layer(ToAdd)
	#arcpy.mapping.AddLayer(df, layer, 'TOP')
	#arcpy.AddMessage(name + ' layer has been trimmed')

TrimInputs(Railroads, TrimPolygon, 'Railroads', mxd, df)
trimmedRailroads = Geodatabase + "\\trimmedRailroads"
arcpy.Buffer_analysis(trimmedRailroads, Railroad_Buffer, '1000 FEET', 'Full', 'Round', 'All', '')
arcpy.AddMessage('Railroads buffered')
arcpy.PolygonToRaster_conversion(Railroad_Buffer, 'OBJECTID', Railroad_Raster, "MAXIMUM_AREA", '', cellsize_option)

reclassify_range = [[1,1,10],["NODATA",1]]
Railroad_Reclass = Reclassify(Railroad_Raster, 'VALUE', RemapRange(reclassify_range), 'DATA')
arcpy.AddMessage('Railroads reclassified')

Finished_Rails = 'Finished Rails'
result = arcpy.MakeRasterLayer_management(Railroad_Reclass, Finished_Rails)
layer = result.getOutput(0)
arcpy.mapping.AddLayer(df, layer)
