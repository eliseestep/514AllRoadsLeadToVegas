''' Script created by Elise Estep and Kyungmin Kim 
for BYU CE En 514 in the Winter 2017 semester. 
Project Title: All Roads Lead to Vegas
Scripts were largely based on scripts provided in
BYU CE En 414 Labs 11 and 12.'''

#Import Modules
import arcpy
import os
from arcpy.sa import *

## Specify the Current Map and Data Frame
mxd = arcpy.mapping.MapDocument('CURRENT')
df = arcpy.mapping.ListDataFrames(mxd,'Layers')[0]

# Get Parameters from ArcGIS dialogue box
'''All template files are included in the AllRoadsDatabase.gdb'''
Railroads = arcpy.GetParameterAsText(0)
Lakes = arcpy.GetParameterAsText(1)
Rivers = arcpy.GetParameterAsText(2)
Highways = arcpy.GetParameterAsText(3)
Cities = arcpy.GetParameterAsText(4)
Slope_Raster = arcpy.GetParameterAsText(5)
'''recommended slope raster is named Slope_template.lyr'''
StartPoint = arcpy.GetParameterAsText(6)
EndPoint = arcpy.GetParameterAsText(7)
Geodatabase = arcpy.GetParameterAsText(8)
Output_Coordinate_System = arcpy.GetParameterAsText(9)
cellsize_option = arcpy.GetParameterAsText(10)
template_layer = arcpy.GetParameterAsText(11)
output_folder = arcpy.GetParameterAsText(12)
'''recommended cover page is called '''
TrimPolygon = arcpy.GetParameterAsText(13)
'''recommended polygon is named Extent'''
CoverPage = arcpy.GetParameterAsText(14) + "\\CoverPage.pdf"

# Set Environments
arcpy.CheckOutExtension('spatial')
arcpy.env.outputCoordinateSystem = Output_Coordinate_System
arcpy.env.overwriteOutput = True
arcpy.env.workspace = Geodatabase
arcpy.env.cellSize = cellsize_option
arcpy.env.extent = Slope_Raster

# Set Global Variables
OutBackLinkRaster = 'OutBackLinkRaster'
temp_shape = 'temp_shape'
temp_clip = 'temp_clip'
Major_Lakes = 'Major_Lakes'
Major_Rivers = 'Major_Rivers'
Railroad_Buffer = 'Railroad_Buffer'
Lakes_Buffer = 'Lakes_Buffer'
Rivers_Buffer = 'Rivers_Buffer'
Highways_Buffer = 'Highways_Buffer'
Cities_Buffer = 'Cities_Buffer'
Railroad_Raster = 'Railroad_Raster'
Lakes_Raster = 'Lakes_Raster'
Rivers_Raster = 'Rivers_Raster'
Highways_Raster = 'Highways_Raster'
Cities_Raster = 'Cities_Raster'
Least_Cost_Path = 'Least_Cost_Path'

# Lists for constant reclasses
'''Reclass tables that are the same for every map. 1 - desirable, 2 - neutral, 10 - to be avoided.'''
Lakes_list = [[1,1,10],["NODATA",1]]
Highways_list = [[1,1,10],["NODATA",1]]
Cities_list = [[1,1,1],["NODATA",2]]
Slope_list = [[0,.02,1],[.02,.04,2],[.04,1,10]]

# Lists for variant reclasses, titles
'''Preset combinations of reclass tables to produce 10 output maps. Railroads can be 1 - desirable, 2 - neutral, or 10 - to be avoided. Streams are 2 - neutral and 10 - to be avoided.'''
Railroads_lists = [[[1,1,1],["NODATA",1]],[[1,1,1],["NODATA",2]],[[1,1,1],["NODATA",10]],[[1,1,2],["NODATA",1]],[[1,1,10],["NODATA",1]],[[1,1,1],["NODATA",1]],[[1,1,1],["NODATA",2]],[[1,1,1],["NODATA",10]],[[1,1,2],["NODATA",1]],[[1,1,10],["NODATA",1]]]
Streams_lists = [[[1,1,2],["NODATA",1]], [[1,1,2],["NODATA",1]], [[1,1,2],["NODATA",1]], [[1,1,2],["NODATA",1]], [[1,1,2],["NODATA",1]], [[1,1,10],["NODATA",1]], [[1,1,10],["NODATA",1]], [[1,1,10],["NODATA",1]], [[1,1,10],["NODATA",1]], [[1,1,10],["NODATA",1]]]
MapTitle = ["Case 1", "Case 2", "Case 3", "Case 4", "Case 5", "Case 6", "Case 7", "Case 8", "Case 9", "Case 10"]

# Functions
def TrimInputs(in_shape, trim_shape, name, mxd, df):
	'''trimming and adding shapefile inputs to the map'''
	inputshape = arcpy.MakeFeatureLayer_management(in_shape, temp_shape)
	inputclip = arcpy.MakeFeatureLayer_management(trim_shape, temp_clip)
	ClipOut = arcpy.Clip_analysis(inputshape, inputclip, 'trimmed' + name)
	arcpy.MakeFeatureLayer_management(ClipOut, 'trimmed' + name + 'layer')
	#ToAdd = 'trimmed' + name + 'layer'
	#layer = arcpy.mapping.Layer(ToAdd)
	#arcpy.mapping.AddLayer(df, layer, 'TOP')
	arcpy.AddMessage(name + ' layer has been trimmed')


# Some coded pre-processing
Start = arcpy.mapping.Layer(StartPoint)
End = arcpy.mapping.Layer(EndPoint)
#arcpy.mapping.AddLayer(df, Start, 'TOP')
#arcpy.mapping.AddLayer(df, End, 'TOP')
arcpy.Select_analysis(Rivers, Major_Rivers, "\"IsMajor\" = 1")
arcpy.Select_analysis(Lakes, Major_Lakes, "\"IsMajor\" >= 1")

## Trim input shapefiles
'''Trimming all input shapefiles to increase speed'''
TrimInputs(Railroads, TrimPolygon, 'Railroads', mxd, df)
TrimInputs(Major_Lakes, TrimPolygon, 'Major_Lakes', mxd, df)
TrimInputs(Major_Rivers, TrimPolygon, 'Major_Rivers', mxd, df)
TrimInputs(Highways, TrimPolygon, 'Highways', mxd, df)
TrimInputs(Cities, TrimPolygon, "Cities", mxd, df)

#Defining the files created by Clip so they can be buffered
trimmedRailroads = Geodatabase + "\\trimmedRailroads"
trimmedMajor_Lakes = Geodatabase + "\\trimmedMajor_Lakes"
trimmedMajor_Rivers = Geodatabase + "\\trimmedMajor_Rivers"
trimmedHighways = Geodatabase + "\\trimmedHighways"
trimmedCities = Geodatabase + "\\trimmedCities"

## Buffering
'''Buffering the trimmed shapefiles'''
arcpy.Buffer_analysis(trimmedRailroads, Railroad_Buffer, '1000 FEET', 'Full', 'Round', 'All', '')
arcpy.AddMessage('Railroads buffered')
arcpy.Buffer_analysis(trimmedMajor_Lakes, Lakes_Buffer, '1 MILE', 'Full', 'Round', 'All', '')
arcpy.AddMessage('Major Lakes buffered')
arcpy.Buffer_analysis(trimmedMajor_Rivers, Rivers_Buffer, '500 FEET', 'Full', 'Round', 'All', '')
arcpy.AddMessage('Major Rivers buffered')
arcpy.Buffer_analysis(trimmedHighways, Highways_Buffer, '1 MILE', 'Full', 'Round', 'All', '')
arcpy.AddMessage('Highways buffered')
arcpy.Buffer_analysis(trimmedCities, Cities_Buffer, '5 MILES', 'Full', 'Round', 'All', '')
arcpy.AddMessage('Cities buffered')


# Buffered Features to Rasters
arcpy.PolygonToRaster_conversion(Railroad_Buffer, 'OBJECTID', Railroad_Raster, "MAXIMUM_AREA", '', cellsize_option)
arcpy.AddMessage('Railroads converted to Raster')
arcpy.PolygonToRaster_conversion(Lakes_Buffer, 'OBJECTID', Lakes_Raster, "MAXIMUM_AREA", '', cellsize_option)
arcpy.AddMessage('Major Lakes converted to Raster')
arcpy.PolygonToRaster_conversion(Rivers_Buffer, 'OBJECTID', Rivers_Raster, "MAXIMUM_AREA", '', cellsize_option)
arcpy.AddMessage('Major Rivers converted to Raster')
arcpy.PolygonToRaster_conversion(Highways_Buffer, 'OBJECTID', Highways_Raster, "MAXIMUM_AREA", '', cellsize_option)
arcpy.AddMessage('Highways converted to Raster')
arcpy.PolygonToRaster_conversion(Cities_Buffer, 'OBJECTID', Cities_Raster, "MAXIMUM_AREA", '', cellsize_option)
arcpy.AddMessage('Cities converted to Raster')

# Reclassify the constants
Lakes_Reclassed = Reclassify(Lakes_Raster, 'VALUE', RemapRange(Lakes_list), 'DATA')
Highways_Reclassed = Reclassify(Highways_Raster, 'VALUE', RemapRange(Highways_list), 'DATA')
Cities_Reclassed = Reclassify(Cities_Raster, 'VALUE', RemapRange(Cities_list), 'DATA')
Slope_Reclassed = Reclassify(Slope_Raster, 'VALUE', RemapRange(Slope_list), 'DATA')
arcpy.AddMessage('Constant feature rasters reclassified')
	
# Start of Code #

## Specify output PDF
pdf_path = output_folder + "\\AllRoadsAtlas.pdf"
arcpy.AddMessage('pdf_path = ' + output_folder + '\\AllRoadsAtlas.pdf')
arcpy.AddMessage('PDF started')

## If that file already exists, delete it
if os.path.exists(pdf_path):
	os.remove(pdf_path)

## Create the atlas PDF file
pdf_doc = arcpy.mapping.PDFDocumentCreate(pdf_path)
arcpy.AddMessage('Creating new atlas')

## Append cover page to PDF file
pdf_doc.appendPages(CoverPage)

for i in range(0,10):
	#Reclassify the variants
	Railroads_Reclassed = Reclassify(Railroad_Raster, 'VALUE', RemapRange(Railroads_lists[i]), 'DATA')
	Streams_Reclassed = Reclassify(Rivers_Raster, 'VALUE', RemapRange(Streams_lists[i]), 'DATA')
	arcpy.AddMessage('Variant feature rasters reclassified for case ' + str(i + 1))
	
	#Calculate Total Raster
	arcpy.AddMessage('-Combining raster values')
	Artificial_Raster = Lakes_Reclassed*Highways_Reclassed*Cities_Reclassed*Slope_Reclassed*Railroads_Reclassed*Streams_Reclassed
	arcpy.AddMessage('Total raster calculated for case ' + str(i + 1))
	
	#Calculate Cost Distance
	arcpy.AddMessage('-Calculating Cost Distance')
	myCostDistance = CostDistance(StartPoint, Artificial_Raster, '', OutBackLinkRaster)
	arcpy.AddMessage('Cost distance calculated for case ' + str(i + 1))
	
	#Calculate Cost Path
	arcpy.AddMessage('-Calculating Cost Path for ' + MapTitle[i])
	myCostPath = CostPath(EndPoint, myCostDistance, OutBackLinkRaster, 'EACH_CELL')
	arcpy.AddMessage('Cost path calculated for case ' + str(i + 1))
	
	#Raster to Polyline
	arcpy.AddMessage('-Convert Raster to Polyline')
	arcpy.RasterToPolyline_conversion(myCostPath, Least_Cost_Path, 'ZERO', '0', 'SIMPLIFY', 'VALUE')
	arcpy.AddMessage('Raster converted to polyline for case ' + str(i + 1))
	
	#Add Polyline to Map and Save
	arcpy.AddMessage('-Add Least Cost Polyline and Save')
	mxd = arcpy.mapping.MapDocument('CURRENT')
	df = arcpy.mapping.ListDataFrames(mxd, 'Layers')[0]
	layer = arcpy.mapping.Layer(Least_Cost_Path)
	arcpy.mapping.AddLayer(df, layer, 'TOP')
	mxd.save()
	arcpy.AddMessage('Polyline mapped for case ' + str(i + 1))
	
	#Change Map Elements By Element Name
	for elm in arcpy.mapping.ListLayoutElements(mxd, "TEXT_ELEMENT"):
		if elm.name == "RIVERS":
			elm.text = str(Streams_lists[i][0][2])
		if elm.name == "RAILROADS":
			elm.text = str(Railroads_lists[i][0][2])
		if elm.name == "NUMBER":
			elm.text = MapTitle[i]
		arcpy.RefreshActiveView()
		arcpy.RefreshTOC()
	arcpy.AddMessage('Layout updated for case ' + str(i + 1))

	#Add Map to PDF
	arcpy.AddMessage('-Appending new map to PDF')
	singlePDF = output_folder + '\\Case' + str(i + 1) + ".pdf"
	arcpy.mapping.ExportToPDF(mxd, singlePDF)
	appendPDF = str(singlePDF)
	pdf_doc.appendPages(appendPDF)
	arcpy.AddMessage('Case ' + str(i+1) + ' appended to PDF')
	
	for lyr in arcpy.mapping.ListLayers(mxd, "", df):
		if lyr.name.lower() == "least_cost_path":
			arcpy.mapping.RemoveLayer(df, lyr)
	arcpy.RefreshTOC()
	arcpy.RefreshActiveView()
	
#Save and Close PDF
pdf_doc.saveAndClose()
	
	