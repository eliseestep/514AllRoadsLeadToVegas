### Test reclassifying and calculating Least Cost

import arcpy
import os
from arcpy.sa import *

mxd = arcpy.mapping.MapDocument("current")
df = arcpy.mapping.ListDataFrames(mxd,"Layers")[0]

