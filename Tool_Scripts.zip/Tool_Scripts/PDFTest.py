import arcpy
import os
from arcpy.sa import *

mxd = arcpy.mapping.MapDocument("current")
df = arcpy.mapping.ListDataFrames(mxd,"Layers")[0]

output_folder = arcpy.GetParameterAsText(0)
#CoverPage = arcpy.GetParameterAsText(1) + "\\" + arcpy.GetParameterAsText(2)
#arcpy.AddMessage(CoverPage)
pdf_path = output_folder + "\\AllRoadsAtlas.pdf"
arcpy.AddMessage(pdf_path)
pdf_doc = arcpy.mapping.PDFDocumentCreate(pdf_path)
singlePDF = arcpy.GetParameterAsText(0) + "\\" + arcpy.GetParameterAsText(2)
arcpy.mapping.ExportToPDF(mxd, singlePDF)
appendPDF = str(singlePDF)
#pdf_doc.appendPages(CoverPage)
pdf_doc.appendPages(appendPDF)
pdf_doc.saveAndClose()
pdf_doc = arcpy.mapping.PDFDocumentOpen(pdf_path)