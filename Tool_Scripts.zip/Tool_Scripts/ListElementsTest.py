import arcpy
#array = [[1,2],[3,50]]
mxd = arcpy.mapping.MapDocument('CURRENT')

for elm in arcpy.mapping.ListLayoutElements(mxd, "TEXT_ELEMENT"):
	if elm.name != "NULL":
		arcpy.AddMessage(elm.name)
	#if elm.name == "LAKES":
	#	elm.text = str(array[1][1])
		

